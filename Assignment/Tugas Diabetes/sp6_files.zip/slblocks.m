function blkStruct = slblocks

blkStruct.Name = 'Real-Time Pacer';
blkStruct.OpenFcn = 'realtime_pacer_lib';
blkStruct.MaskInitialization = '';
