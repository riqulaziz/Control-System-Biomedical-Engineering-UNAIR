clc;close all;clear all

K=20;
t1=10;t2=5;
tc=5;
ti=t1+t2;
td=t1*t2/ti;

Kc=ti./(tc.*K);
Kpi=Kc./ti;
Kpd=Kc.*td;




