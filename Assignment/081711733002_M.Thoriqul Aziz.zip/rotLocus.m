clc;clear;close all;

Gc=tf([1],[50 15 1]);
figure;rlocus(Gc)
K=0.265;
Gcp=series(K,Gc);
Gcl=feedback(Gcp,1)
figure;step(Gcl)
